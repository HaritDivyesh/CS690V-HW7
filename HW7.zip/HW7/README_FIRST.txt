CS690V HW7: Divyesh Harit

INSTRUCTIONS AND NOTES:
Made in Python 3.
The code takes around 1hr to run. There's around 1.2M messages; my modest machine could barely handle it. Not sure if the interactions are super smooth, they weren't on my machine!
Jupyter notebook was giving an "IOPub data rate exceeded" error for me initially. To fix this, run the notebook using the following command in sudo mode: jupyter notebook --allow-root --NotebookApp.iopub_data_rate_limit=100000000  HW7.ipynb.
